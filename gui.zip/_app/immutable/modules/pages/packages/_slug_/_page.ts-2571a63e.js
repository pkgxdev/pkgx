import{l}from"../../../../chunks/_page-92eda0af.js";export{l as load};
