import{p as e,s as p}from"../../chunks/_layout-c0ee69eb.js";export{e as prerender,p as ssr};
