import{default as t}from"../components/pages/others/_page.svelte-8e55e585.js";export{t as component};
