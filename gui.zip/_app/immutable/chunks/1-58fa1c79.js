import{default as t}from"../components/error.svelte-a4d6db11.js";export{t as component};
