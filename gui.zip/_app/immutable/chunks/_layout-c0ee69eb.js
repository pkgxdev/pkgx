const e=!1,r=!1,s=Object.freeze(Object.defineProperty({__proto__:null,ssr:!1,prerender:!1},Symbol.toStringTag,{value:"Module"}));export{s as _,r as p,e as s};
