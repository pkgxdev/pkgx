import{default as t}from"../components/pages/cli/_page.svelte-8b5257ae.js";export{t as component};
