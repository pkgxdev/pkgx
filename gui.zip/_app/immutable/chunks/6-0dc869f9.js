import{default as t}from"../components/pages/packages/_page.svelte-8415f663.js";export{t as component};
