import{default as t}from"../components/pages/documentation/_page.svelte-d9a0bbbf.js";export{t as component};
