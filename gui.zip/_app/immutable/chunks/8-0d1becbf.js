import{default as t}from"../components/pages/profile/_page.svelte-90e6e71d.js";export{t as component};
