import{_ as r}from"./_layout-c0ee69eb.js";import{default as t}from"../components/pages/_layout.svelte-8ba00679.js";export{t as component,r as shared};
