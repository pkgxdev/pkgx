import{default as t}from"../components/pages/_page.svelte-361eaa74.js";export{t as component};
