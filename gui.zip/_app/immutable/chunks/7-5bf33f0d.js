import{_ as r}from"./_page-92eda0af.js";import{default as t}from"../components/pages/packages/_slug_/_page.svelte-d83fa95c.js";export{t as component,r as shared};
